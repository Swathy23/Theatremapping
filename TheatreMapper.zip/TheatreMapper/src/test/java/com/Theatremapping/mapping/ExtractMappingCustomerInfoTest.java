package com.Theatremapping.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.Theatremapping.model.Customer;
import com.Theatremapping.model.MappingandCustomerRequest;

public class ExtractMappingCustomerInfoTest {


    ExtractMappingandCustomerOrder testingObject;
    MappingandCustomerRequest mappingandCustomerRequest;
    Customer customer;
    TreeMap<Integer, Customer> customerMap = new TreeMap<Integer, Customer>();

    @Before
    public void init() {
        testingObject = new ExtractMappingandCustomerOrder();
        mappingandCustomerRequest = new MappingandCustomerRequest();
        mappingandCustomerRequest.setTotalLines(5);
        mappingandCustomerRequest.setEmptyLineNumber(3);
    }

    @Test
    public void extractMappingAndCustomerOrder_HappyPath() {

        customer = new Customer("Test77", 3);
        Customer customer1 = new Customer("Test88", 4);
        customerMap.put(1, customer);
        customerMap.put(2, customer1);
        mappingandCustomerRequest.setCustomerMap(customerMap);

        List<StringBuilder> lineReaderText = new ArrayList<>();
        lineReaderText.add(new StringBuilder("3 3"));
        lineReaderText.add(new StringBuilder("4 3"));
        lineReaderText.add(new StringBuilder(" "));
        lineReaderText.add(new StringBuilder("Test77 3"));
        lineReaderText.add(new StringBuilder("Test88 4"));
        mappingandCustomerRequest.setLineReaderText(lineReaderText);
        testingObject.extractMappingandCustomerOrder(mappingandCustomerRequest);
        Assert.assertEquals(testingObject.getHighestSeatSection(), 4);
        Assert.assertEquals(testingObject.getTotalTheaterSeats(), 13);

    }

    @Test
    public void extractSeatingAndCustomerOrder_NoDataPassed_NoExceptions() {

        testingObject.extractMappingandCustomerOrder(mappingandCustomerRequest);
        Assert.assertEquals(testingObject.getHighestSeatSection(), 0);
        Assert.assertEquals(testingObject.getTotalTheaterSeats(), 0);

    }

}
