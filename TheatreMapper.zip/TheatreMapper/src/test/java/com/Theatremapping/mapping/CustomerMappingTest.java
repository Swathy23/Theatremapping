package com.Theatremapping.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.Theatremapping.model.Customer;
import com.Theatremapping.model.MappingandCustomerRequest;

public class CustomerMappingTest {
	public static final String TEST = "Test";
    public static final String TEST1 = "Test1";
    CustomerMapping testObject;
    MappingandCustomerRequest mappingandCustomerRequest;
    Customer customer;
    TreeMap<Integer, Customer> customerMap = new TreeMap<Integer, Customer>();



    @Before
    public void init(){

        testObject = new CustomerMapping();
        mappingandCustomerRequest = new MappingandCustomerRequest();
        mappingandCustomerRequest.setTotalLines(5);
        mappingandCustomerRequest.setEmptyLineNumber(3);
        int[][] seatingMatrix = new int[6][6];
        seatingMatrix[1][1] = 3;
        seatingMatrix[1][2] = 3;
        seatingMatrix[2][1] = 4;
        seatingMatrix[2][2] = 3;
        mappingandCustomerRequest.setSeatingMatrix(seatingMatrix);

    }

    @Test
    public void testExtractSeatingAndCustomerOrder_HappyPath(){
        customer = new Customer(TEST, 3);
        Customer customer1 = new Customer(TEST1, 4);
        customerMap.put(1, customer);
        customerMap.put(2, customer1);
        mappingandCustomerRequest.setCustomerMap(customerMap);

        List<StringBuilder> lineReaderText = new ArrayList<>();
        lineReaderText.add(new StringBuilder("3 3"));
        lineReaderText.add(new StringBuilder("4 3"));
        lineReaderText.add(new StringBuilder(" "));
        lineReaderText.add(new StringBuilder("Test 3"));
        lineReaderText.add(new StringBuilder("Test1 4"));
        mappingandCustomerRequest.setLineReaderText(lineReaderText);


        testObject.processSeating(mappingandCustomerRequest, 4, 13);
        mappingandCustomerRequest.getCustomerMap().forEach((key, customer)-> {
            if(customer.getName().equals(TEST)) {
                Assert.assertTrue(customer.getRowAssigned() == 1);
                Assert.assertTrue(customer.getSectionAssigned() == 1);
            }
            if(customer.getName().equals(TEST1)) {
                Assert.assertTrue(customer.getRowAssigned() == 2);
                Assert.assertTrue(customer.getSectionAssigned() == 1);
            }

        });
    }

    @Test
    public void testextractMappingAndCustomerOrder_LargeOrder(){

        customer = new Customer(TEST, 100);
        Customer customer1 = new Customer(TEST1, 4);
        customerMap.put(1, customer);
        customerMap.put(2, customer1);
        mappingandCustomerRequest.setCustomerMap(customerMap);

        List<StringBuilder> lineReaderText = new ArrayList<>();
        lineReaderText.add(new StringBuilder("3 3"));
        lineReaderText.add(new StringBuilder("4 3"));
        lineReaderText.add(new StringBuilder(" "));
        lineReaderText.add(new StringBuilder("Test 100"));
        lineReaderText.add(new StringBuilder("Test1 4"));
        mappingandCustomerRequest.setLineReaderText(lineReaderText);


        testObject.processSeating(mappingandCustomerRequest, 4, 13);
        mappingandCustomerRequest.getCustomerMap().forEach((key, customer)-> {
            if(customer.getName().equals(TEST)) {
                Assert.assertTrue(customer.getRowAssigned() == null);
                Assert.assertTrue(customer.getComments().equals(CustomerMapping.CANNOT_HANDLE_PARTY_MSG));
            }
            if(customer.getName().equals(TEST1)) {
                Assert.assertTrue(customer.getRowAssigned() == 2);
                Assert.assertTrue(customer.getSectionAssigned() == 1);
            }

        });
    }

    @Test
    public void testextractMappingAndCustomerOrder_SplitOrder(){

        customer = new Customer(TEST, 9);
        Customer customer1 = new Customer(TEST1, 4);
        customerMap.put(1, customer);
        customerMap.put(2, customer1);
        mappingandCustomerRequest.setCustomerMap(customerMap);

        List<StringBuilder> lineReaderText = new ArrayList<>();
        lineReaderText.add(new StringBuilder("3 3"));
        lineReaderText.add(new StringBuilder("4 3"));
        lineReaderText.add(new StringBuilder(" "));
        lineReaderText.add(new StringBuilder("Test 100"));
        lineReaderText.add(new StringBuilder("Test1 4"));
        mappingandCustomerRequest.setLineReaderText(lineReaderText);


        testObject.processSeating(mappingandCustomerRequest, 4, 13);
        mappingandCustomerRequest.getCustomerMap().forEach((key, customer)-> {
            if(customer.getName().equals(TEST)) {
                Assert.assertTrue(customer.getRowAssigned() == null);
                Assert.assertTrue(customer.getComments().equals(CustomerMapping.SPLIT_PARTY_MSG));
            }
            if(customer.getName().equals(TEST1)) {
                Assert.assertTrue(customer.getRowAssigned() == 2);
                Assert.assertTrue(customer.getSectionAssigned() == 1);
            }

        });
    }

    @Test
    public void testextractSeatingAndCustomerOrder_CloseToFront(){

        customer = new Customer(TEST, 2);
        Customer customer1 = new Customer(TEST1, 4);
        customerMap.put(1, customer);
        customerMap.put(2, customer1);
        mappingandCustomerRequest.setCustomerMap(customerMap);
        int[][] seatingMatrix = new int[6][6];
        seatingMatrix[1][1] = 3;
        seatingMatrix[1][2] = 3;
        seatingMatrix[2][1] = 4;
        seatingMatrix[2][2] = 3;
        seatingMatrix[3][1] = 4;
        seatingMatrix[3][2] = 2;
        mappingandCustomerRequest.setSeatingMatrix(seatingMatrix);

        List<StringBuilder> lineReaderText = new ArrayList<>();
        lineReaderText.add(new StringBuilder("3 3"));
        lineReaderText.add(new StringBuilder("4 3"));
        lineReaderText.add(new StringBuilder("4 2"));
        lineReaderText.add(new StringBuilder(" "));
        lineReaderText.add(new StringBuilder("Test 2"));
        lineReaderText.add(new StringBuilder("Test1 4"));
        MappingandCustomerRequest.setLineReaderText(lineReaderText);


        testObject.processSeating(mappingandCustomerRequest, 4, 13);

        mappingandCustomerRequest.getCustomerMap().forEach((key, customer)-> {
            if(customer.getName().equals(TEST)) {
                Assert.assertTrue(customer.getRowAssigned() == 3);
                Assert.assertTrue(customer.getSectionAssigned() == 2);
            }
            if(customer.getName().equals(TEST1)) {
                Assert.assertTrue(customer.getRowAssigned() == 2);
                Assert.assertTrue(customer.getSectionAssigned() == 1);
            }

        });
    }


}
