package com.Theatremapping.procedure;

import org.junit.Assert;
import org.junit.Test;

import com.Theatremapping.model.MappingandCustomerRequest;

public class ProcedureforPreSaleRequestTest {
	ProcedureforPreSaleRequests procedureforPreSaleRequests;

    @Test
    public void processInputFile_HappyPath() {
        procedureforPreSaleRequests = new ProcedureforPreSaleRequests();

        MappingandCustomerRequest mappingandCustomerRequest = procedureforPreSaleRequests.extractInfoFromFile("test_resource.txt");
        Assert.assertNotNull(mappingandCustomerRequest);
        Assert.assertNotNull(mappingandCustomerRequest.getCustomerMap());

        mappingandCustomerRequest.getCustomerMap().forEach((key, customer)->{
            if(customer.getName().equals("Test33")) {
                Assert.assertTrue(customer.getRowAssigned() == 1);
                Assert.assertTrue(customer.getSectionAssigned() == 1);
            }
            if(customer.getName().equals("Test56")) {
                Assert.assertTrue(customer.getRowAssigned() == 2);
                Assert.assertTrue(customer.getSectionAssigned() == 2);
            }
        });


    }


    @Test
    public void processInputFile_FileNoIssue() {
        procedureforPreSaleRequests = new ProcedureforPreSaleRequests();
        try {

            procedureforPreSaleRequests.extractInfoFromFile("test_resource.txt");
        } catch (Exception e) {
            Assert.fail("Exception " + e);
        }

    }

    @Test
    public void processInputFile_FileNotFound() {
        procedureforPreSaleRequests = new ProcedureforPreSaleRequests();
        try {

            procedureforPreSaleRequests.extractInfoFromFile("nonametest_resource.txt");
            Assert.fail("Exception should have been thrown");

        } catch (Exception e) {

        }

    }

}
