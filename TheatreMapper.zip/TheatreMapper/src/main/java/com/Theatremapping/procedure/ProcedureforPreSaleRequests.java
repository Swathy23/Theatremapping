package com.Theatremapping.procedure;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import com.Theatremapping.model.Customer;
import com.Theatremapping.model.MappingandCustomerRequest;
import com.Theatremapping.sample.SampleTheatremapping;

public class ProcedureforPreSaleRequests {
	 public MappingandCustomerRequest extractInfoFromFile(String fileName) {
	        InputStream resourceAsStream = null;
	        TreeMap<Integer, Customer> customerMap = new TreeMap<Integer, Customer>();
	        MappingandCustomerRequest mappingandCustomerRequest = null;

	        try {
	            LineNumberReader in = new LineNumberReader(new InputStreamReader(SampleTheatremapping.class.getClassLoader().getResourceAsStream(fileName)));
	            int emptyLineNumber = 0;
	            Integer totalLines = new Integer(0);

	            List<StringBuilder> lineReaderText = new ArrayList<>();
	            String line = null;


	            while ((line = in.readLine()) != null) {
	                lineReaderText.add(totalLines, new StringBuilder(line));
	                if (line.trim().isEmpty()) {
	                    emptyLineNumber = in.getLineNumber() - 1;
	                }
	                totalLines++;
	            }

	            mappingandCustomerRequest = setMappingandCustomerRequest(customerMap, emptyLineNumber, totalLines, lineReaderText);


	        } catch (IOException ioe) {
	            ioe.printStackTrace();
	            System.out.println("Sorry, error while reading input file");
	        } finally {
	            if (resourceAsStream != null) {
	                try {
	                    resourceAsStream.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                    System.out.println("Sorry, error while closing input reader");

	                }
	            }
	        }
	        return mappingandCustomerRequest;
	    }

	    private MappingandCustomerRequest setMappingandCustomerRequest(TreeMap<Integer, Customer> customerMap, int emptyLineNumber, Integer totalLines, List<StringBuilder> lineReaderText) {
	        MappingandCustomerRequest mappingandCustomerRequest;
	        int[][] mappingMatrix = new int[6][6];
	        mappingandCustomerRequest = new MappingandCustomerRequest();
	        mappingandCustomerRequest.setEmptyLineNumber(emptyLineNumber);
	        mappingandCustomerRequest.setLineReaderText(lineReaderText);
	        mappingandCustomerRequest.setCustomerMap(customerMap);
	        mappingandCustomerRequest.setSeatingMatrix(mappingMatrix);
	        mappingandCustomerRequest.setTotalLines(totalLines);
	        return mappingandCustomerRequest;
	    }

	}

