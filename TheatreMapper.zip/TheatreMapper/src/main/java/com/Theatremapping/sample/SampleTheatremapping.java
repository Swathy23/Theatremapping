package com.Theatremapping.sample;

import java.io.IOException;

import com.Theatremapping.mapping.CustomerMapping;
import com.Theatremapping.mapping.ExtractMappingandCustomerOrder;
import com.Theatremapping.mapping.PrintTheatreMapping;
import com.Theatremapping.model.MappingandCustomerRequest;
import com.Theatremapping.procedure.ProcedureforPreSaleRequests;

public class SampleTheatremapping {
	public static void main(String[] args) throws IOException {

        ProcedureforPreSaleRequests procedureforPreSaleRequests = new ProcedureforPreSaleRequests();
        MappingandCustomerRequest mappingandCustomerRequest = procedureforPreSaleRequests.extractInfoFromFile("theatre_layout.txt");

        ExtractMappingandCustomerOrder extractMappingandCustomerOrder = new ExtractMappingandCustomerOrder();
        extractMappingandCustomerOrder.extractMappingandCustomerOrder(mappingandCustomerRequest);

        new CustomerMapping().processSeating(mappingandCustomerRequest, extractMappingandCustomerOrder.getHighestSeatSection(), extractMappingandCustomerOrder.getTotalTheaterSeats());

        new PrintTheatreMapping().printMappingAssignments(mappingandCustomerRequest.getCustomerMap());


    }

}
