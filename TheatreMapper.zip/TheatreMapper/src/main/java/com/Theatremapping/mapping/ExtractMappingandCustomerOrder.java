package com.Theatremapping.mapping;

import java.util.List;
import java.util.TreeMap;

import com.Theatremapping.model.Customer;
import com.Theatremapping.model.MappingandCustomerRequest;

public class ExtractMappingandCustomerOrder {
	private int highestSeatSection;
    private int totalTheaterSeats;

    public void extractMappingandCustomerOrder(	MappingandCustomerRequest mappingandCustomerRequest) {
        for (int i = 0, j = 1, partyKey = 1; i < mappingandCustomerRequest.getTotalLines(); i++, j++) {
            if (i > mappingandCustomerRequest.getEmptyLineNumber()) {
                partyKey = extractCustomerOrder(mappingandCustomerRequest.getCustomerMap(), mappingandCustomerRequest.getLineReaderText(), i, partyKey);

            } else if (i < mappingandCustomerRequest.getEmptyLineNumber()) {
                extractMappingMatrix(mappingandCustomerRequest.getLineReaderText(), mappingandCustomerRequest.getSeatingMatrix(), i, j);
            }

        }

    }

    private void extractMappingMatrix(List<StringBuilder> lineReaderText, int[][] mappingMatrix, int i, int j) {
        if (!lineReaderText.isEmpty()) {
            String[] sectionList = lineReaderText.get(i).toString().split(" ");

            for (int section = 0, k = 1; section < sectionList.length; section++, k++) {
                int sectionSeatsCount = Integer.parseInt(sectionList[section]);
                highestSeatSection = Math.max(highestSeatSection, sectionSeatsCount);
                totalTheaterSeats = totalTheaterSeats + sectionSeatsCount;
                mappingMatrix[j][k] = sectionSeatsCount;
            }
        }
    }

    private int extractCustomerOrder(TreeMap<Integer, Customer> customerMap, List<StringBuilder> lineReaderText, int i, int partyKey) {
        if (!lineReaderText.isEmpty()) {
            String[] custmomerList = lineReaderText.get(i).toString().split(" ");
            Customer seatingSection = new Customer(custmomerList[0], Integer.parseInt(custmomerList[1]));
            customerMap.put(partyKey++, seatingSection);
        }
        return partyKey;
    }

    public int getHighestSeatSection() {
        return highestSeatSection;
    }

    public int getTotalTheaterSeats() {
        return totalTheaterSeats;
    }
}
