package com.Theatremapping.mapping;

import java.util.TreeMap;

import com.Theatremapping.model.Customer;
import com.Theatremapping.model.MappingandCustomerRequest;

public class CustomerMapping {
	public final static String CANNOT_HANDLE_PARTY_MSG = " Sorry we can't handle your party.";
    public final static String SPLIT_PARTY_MSG = " Call to split party.";
    private int highestSeatSection;
    private int totalTheaterSeats;

    public void processSeating(MappingandCustomerRequest mappingandCustomerRequest, int highestSeatSection, int totalTheaterSeats) {

        this.highestSeatSection = highestSeatSection;
        this.totalTheaterSeats = totalTheaterSeats;
        MappingToCustomers(mappingandCustomerRequest.getCustomerMap(), mappingandCustomerRequest.getSeatingMatrix());
        handleSplitOrders(mappingandCustomerRequest.getCustomerMap());
        handleLargeOrders(mappingandCustomerRequest.getCustomerMap());
    }


   
    private void handleSplitOrders(TreeMap<Integer, Customer> customerMap) {
        customerMap.forEach((key, customer) -> {
            if (customer.getmappingNeeded() > highestSeatSection) {
                customer.setComments(SPLIT_PARTY_MSG);
            }

        });
    }

   
    private void handleLargeOrders(TreeMap<Integer, Customer> customerMap) {
        customerMap.forEach((key, customer) -> {
            if (customer.getmappingNeeded() > totalTheaterSeats) {
                customer.setComments(CANNOT_HANDLE_PARTY_MSG);
            }

        });
    }

   
    private void MappingToCustomers(TreeMap<Integer, Customer> customerMap, int[][] mappingMatrix) {
        customerMap.forEach((key, customer) -> {
            customerLoop:
            for (int row = 1; row < 6; row++) {
                for (int section = 1; section < 6; section++) {
                    //If exact match and within 3 row
                    if ((mappingMatrix[row][section] == customer.getmappingNeeded() && row < 4) && customer.getRowAssigned() == null) {
                        customer.setRowAssigned(row);
                        customer.setSectionAssigned(section);
                        break customerLoop;
                    }
                    if (mappingMatrix[row][section] == customer.getmappingNeeded() && row >= 4 && customer.getRowAssigned() == null) {
                        //Check if higher number is available in front rows
                        for (int rowRepeater = 1; rowRepeater < 4; rowRepeater++) {
                            for (int sectionRepeater = 1; sectionRepeater < 6; sectionRepeater++) {
                                if ((mappingMatrix[rowRepeater][sectionRepeater] > customer.getmappingNeeded()) && customer.getRowAssigned() == null) {
                                    customer.setRowAssigned(rowRepeater);
                                    customer.setSectionAssigned(sectionRepeater);
                                    mappingMatrix[rowRepeater][sectionRepeater] = mappingMatrix[rowRepeater][sectionRepeater] - customer.getmappingNeeded();
                                    break customerLoop;
                                }
                            }
                            customer.setRowAssigned(row);
                            customer.setSectionAssigned(section);
                            break customerLoop;
                        }
                    }
                }
            }
        });
    }
	
	
}
