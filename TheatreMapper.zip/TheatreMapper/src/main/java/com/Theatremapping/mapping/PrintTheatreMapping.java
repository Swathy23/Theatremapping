package com.Theatremapping.mapping;

import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;

import com.Theatremapping.model.Customer;

public class PrintTheatreMapping {
	public void printMappingAssignments(TreeMap<Integer, Customer> customerTreeMap) {
        customerTreeMap.forEach((key, customer) -> {
            StringBuilder printAssignment = new StringBuilder();
            printAssignment.append(customer.getName());
            if (StringUtils.isBlank(customer.getComments()) && customer.getRowAssigned() != null && customer.getSectionAssigned() != null) {
                printAssignment.append(" Row " + customer.getRowAssigned() + " Section " + customer.getSectionAssigned());

            } else if (StringUtils.isNotBlank(customer.getComments())) {
                printAssignment.append(customer.getComments());
            }
            System.out.println(printAssignment);

        });
    }
}
